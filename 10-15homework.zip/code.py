"""
* Writer : ys
* Program : rock scissor paper
* action : print the results of the games
"""
import random
A = {"r", "s", "p"}
B = {"r", "s", "p"}
for _ in range(10):
	Ap = A[random.randrange(3)]
	Bp = B[random.randrange(3)]
	if (Ap=="r" and Bp=="s") or (Ap=="s" and Bp=="p") or (Ap=="p" and Bp=="r"):
		print("A win \n")
	elif (Ap=="s" and Bp=="r") or (Ap=="p" and Bp=="s") or (Ap=="r" and Bp=="p"):
		print("B win \n")
	else:
		print("Draw\n")